#ifndef COMMONCPU
#define COMMONCPU
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <string.h>
#include <string>     // std::string, std::to_string
#include <stdint.h>
#include "types.hpp"
#include "timers.hpp"


#endif
